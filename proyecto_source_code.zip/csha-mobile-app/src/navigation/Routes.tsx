import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import AuthStack from './AuthStack';
import HomeDrawer from './HomeDrawer';
import {useAuthContext} from './AuthProvider';
import ChangePasswordScreen from '../screens/ChangePasswordScreen';

export default function Routes() {
  const {isSignedIn, isFirstTime} = useAuthContext();

  return (
    <>
      <NavigationContainer>
        {isFirstTime ? <ChangePasswordScreen isFirstTime={isFirstTime} /> : isSignedIn ? <HomeDrawer /> : <AuthStack />}
      </NavigationContainer>
    </>
  );
}
