import React, {createContext, useState} from 'react';
import {apiChangePassword, apiLogIn, apiLogOut, apiResetPassword, getUserPermisos} from '../services/api';
import {IAuthtenticate, IPasswordChange, IPasswordReset} from '../services/types';

export interface IAuthContext {
  isSignedIn: boolean;
  userId: Maybe<string>;
  fullName: Maybe<string>;
  email: Maybe<string>;
  tokenId: Maybe<string>;
  permisos: Maybe<string>;
  logIn: (data: IAuthtenticate) => Promise<any>;
  resetPassword: (data: IPasswordReset) => Promise<void>;
  changePassword: (data: IPasswordChange) => Promise<boolean>;
  logOut: (tokenId: string) => Promise<any>;
}

interface Props {
  children: React.ReactNode;
}

export const AUTH_CONTEXT_DEFAULT_VALUE = {
  isSignedIn: false,
  userId: null,
  fullName: null,
  email: null,
  tokenId: null,
  permisos: null,
  logIn: async () => {
    return;
  },
  resetPassword: async () => {
    return;
  },
  changePassword: async () => {
    return false;
  },
  logOut: async () => {}
};

export const AuthContext = createContext<IAuthContext>(AUTH_CONTEXT_DEFAULT_VALUE);

function processPermisos(permisos) {
  const permisosFormatted = {};
  permisos.forEach((permiso) => {
    permisosFormatted[permiso.modulo_cod] = {};
    permiso.permisos.forEach((permisoTipo) => {
      permisosFormatted[permiso.modulo_cod][permisoTipo.permiso_cod] = true;
    });
  });
  return permisosFormatted;
}

export const AuthProvider = ({children}: Props) => {
  const [isSignedIn, setIsSignedIn] = useState<boolean>(false);
  const [userId, setUserId] = useState<Maybe<string>>(null);
  const [fullName, setFullName] = useState<Maybe<string>>(null);
  const [socioId, setSocioId] = useState<Maybe<string>>(null);
  const [isFirstTime, setIsFirstTime] = useState<Maybe<string>>(false);
  const [email, setEmail] = useState<Maybe<string>>(null);
  const [tokenId, setTokenId] = useState<Maybe<string>>(null);
  const [permisos, setPermisos] = useState<Maybe<string>>({});

  const logIn = async (data: IAuthtenticate) => {
    const response = await apiLogIn(data);
    if (response.data?.resultado === `SI`) {
      if (response.data.es_primer_ingreso === `SI`) {
        setIsFirstTime(true);
      } else {
        setIsFirstTime(false);
      }
      setPermisos(processPermisos(response.data.modulos_permisos));
      setIsSignedIn(true);
      setEmail(data.email);
      setSocioId(response.data.socio_id);
      setTokenId(response.data[`token_id`]);
      return {result: true, response};
    }
    return {result: false, response};
  };

  const logOut = async (tokenId: string) => {
    const response = await apiLogOut(tokenId);
    if (response.status === 200) {
      setIsSignedIn(false);
    } else {
      setIsSignedIn(false);
    }
    if (isFirstTime) {
      setIsFirstTime(false);
    }
  };

  const updatePermisos = async () => {
    const response = await getUserPermisos(tokenId);
    const currentPermisos = processPermisos(response.data);
    setPermisos(currentPermisos);
  };

  const resetPassword = async (data: IPasswordReset) => {
    const response = await apiResetPassword(data);
  };

  const changePassword = async (data: IPasswordChange): Promise<boolean> => {
    const response = await apiChangePassword(data);
    if (response.status === 200) {
      if (!response.data.status) {
        await logOut(data.tokenId);
        return {changed: true};
      }
      return {changed: false, message: response.data.mensaje};
    } else {
      return {changed: false, message: `Ha ocurrido un error.`};
    }
  };

  const cleanValues = async (): Promise<void> => {
    setIsSignedIn(false);
    setTokenId(``);
    setEmail(``);
  };

  const value = {
    isSignedIn,
    socioId,
    userId,
    fullName,
    email,
    tokenId,
    permisos,
    isFirstTime,
    updatePermisos,
    logIn,
    resetPassword,
    changePassword,
    logOut
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuthContext = (): IAuthContext => {
  const context = React.useContext(AuthContext);
  if (!context) {
    throw new Error(`[useAuthContext] Hook not used under auth context provider`);
  }
  return context;
};
