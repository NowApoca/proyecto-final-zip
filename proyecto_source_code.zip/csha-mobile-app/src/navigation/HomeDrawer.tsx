import React, {useContext} from 'react';
import {View, Button, StyleSheet} from 'react-native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import LogoTitle from '../components/LogoTitle';
/** SCREEENS */
import HomeScreen from '../screens/HomeScreen';
import FAQScreen from '../screens/FAQScreen';
import LogOutScreen from '../screens/LogOutScreen';
import SupportScreen from '../screens/SupportScreen';
import Invitations from '../screens/InvitationsScreen';
import MyProfileScreen from '../screens/MyProfileScreen';
import FamilyGroupScreen from '../screens/FamilyGroupScreen';
import ChangePasswordScreen from '../screens/ChangePasswordScreen';
/** SCREENS */
import {BACKGROUND_COLOUR, fontScale, PRIMARY_COLOR, SECONDARY_COLOR, THIRD_COLOR} from '../styles/common';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {black} from 'react-native-paper/lib/typescript/styles/colors';
import IndividualGroupMember from '../components/FamilyGroup/IndividualGroupMember';
import {AuthContext} from './AuthProvider';
import {PedidosScreen} from '../screens/ComensalesScreen';
import CanchasScreen from '../screens/CanchasScreen';
import NotificationsScreen from '../screens/Notifications';

const style = StyleSheet.create({
  container: {backgroundColor: BACKGROUND_COLOUR, flex: 1, alignItems: `center`, justifyContent: `center`}
});

const Drawer = createDrawerNavigator();

const HomeDrawer = () => {
  const {permisos} = useContext(AuthContext);

  return (
    <Drawer.Navigator
      initialRouteName="Home"
      screenOptions={{
        drawerAllowFontScaling: true,
        headerStyle: {
          backgroundColor: SECONDARY_COLOR
        },
        headerTintColor: `#fff`,
        headerTitleStyle: {
          fontWeight: `bold`
        }
      }}
    >
      <Drawer.Screen
        name="home"
        component={HomeScreen}
        options={{
          title: `Inicio`,
          drawerAllowFontScaling: true,
          drawerItemStyle: {
            borderBottomWidth: 1,
            borderColor: THIRD_COLOR
          },
          headerRight: () => <LogoTitle backgroundColor={`white`} />
        }}
      />

      <Drawer.Screen
        name="invitation"
        options={{
          drawerAllowFontScaling: true,
          drawerLabelStyle: {
            fontSize: 20,
            color: `black`
          },
          title: `Invitaciones`
        }}
        component={Invitations}
      />

      <Drawer.Screen
        name="information"
        options={{
          drawerAllowFontScaling: true,
          drawerLabelStyle: {
            fontSize: 25 * fontScale,
            color: `black`
          },
          title: `Informacion`
        }}
        component={MyProfileScreen}
      />

      <Drawer.Screen
        name="perfil"
        options={{
          drawerAllowFontScaling: true,
          title: `Mi perfil`,
          drawerIcon: () => <FontAwesome name={`user`} color={PRIMARY_COLOR} size={18} />
        }}
        component={MyProfileScreen}
      />
      {permisos[`GRUPO_FAMILIAR`] && permisos[`GRUPO_FAMILIAR`][`ABRIR`] && (
        <Drawer.Screen
          name="familyGroup"
          options={{
            drawerAllowFontScaling: true,
            title: `Grupo Familiar`,
            drawerIcon: () => <FontAwesome name={`users`} color={PRIMARY_COLOR} size={18} />
          }}
          component={FamilyGroupScreen}
        />
      )}
      <Drawer.Screen
        name="changePassword"
        options={{
          title: `Cambiar contraseña`,
          drawerAllowFontScaling: true,
          drawerItemStyle: {
            borderBottomWidth: 1,
            borderColor: THIRD_COLOR
          },
          drawerIcon: () => <FontAwesome name={`lock`} color={PRIMARY_COLOR} size={18} />
        }}
        component={ChangePasswordScreen}
      />
      <Drawer.Screen
        name="notification"
        options={{
          title: `Notificaciones`,
          drawerAllowFontScaling: true,
          drawerIcon: () => <FontAwesome name={`bell`} color={PRIMARY_COLOR} size={18} />
        }}
        component={NotificationsScreen}
      />
      <Drawer.Screen
        name="FAQ"
        options={{
          title: `Preguntas Frecuentes`,
          drawerAllowFontScaling: true,
          drawerIcon: () => <FontAwesome name={`question-circle-o`} color={PRIMARY_COLOR} size={18} />
        }}
        component={FAQScreen}
      />
      <Drawer.Screen
        name="support"
        options={{
          title: `Soporte`,
          drawerAllowFontScaling: true,
          drawerItemStyle: {
            borderBottomWidth: 1,
            borderColor: THIRD_COLOR
          },
          drawerIcon: () => <FontAwesome name={`headphones`} color={PRIMARY_COLOR} size={18} />
        }}
        component={SupportScreen}
      />
      <Drawer.Screen
        name="logOut"
        options={{
          title: `Cerrar Sesión`,
          drawerAllowFontScaling: true,
          drawerIcon: () => <Ionicons name="log-out-outline" size={18} color={`black`} />
        }}
        component={LogOutScreen}
      />

      <Drawer.Screen
        name="IndividualGroupMember"
        options={{
          title: ``,
          drawerAllowFontScaling: true
        }}
        component={IndividualGroupMember}
      />

      <Drawer.Screen
        name="pedidos"
        options={{
          title: `Mis Pedidos`
        }}
        component={PedidosScreen}
      />

      <Drawer.Screen
        name="canchas"
        options={{
          title: `Mis reservas`
        }}
        component={CanchasScreen}
      />
    </Drawer.Navigator>
  );
};

export default HomeDrawer;
