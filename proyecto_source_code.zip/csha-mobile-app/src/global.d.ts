declare type Maybe<T> = T | null
