import React, {useContext} from 'react';
import {AuthContext} from '../navigation/AuthProvider';

export default function ResetPasswordScreen({}) {
  const {logIn} = useContext(AuthContext);

  return <></>;
}
