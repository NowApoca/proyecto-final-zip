import React, {useContext, useRef, useState} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {Divider, Button} from 'react-native-paper';
import {useToast} from 'react-native-toast-notifications';
import PasswordInput from '../components/Inputs/Password';
import {AuthContext} from '../navigation/AuthProvider';
import {IPasswordChange} from '../services/types';
import {
  BACKGROUND_COLOUR,
  fontScale,
  PRIMARY_COLOR,
  PRIMARY_TEXT_COLOR,
  RED_COLOR,
  THIRD_COLOR
} from '../styles/common';
import {TextInput} from 'react-native-paper';

export default function ChangePasswordScreen({navigation, isFirstTime}: any) {
  const toast = useToast();
  const {changePassword, tokenId} = useContext(AuthContext);

  const [currentPassword, setCurrentPassword] = useState(``);
  const [newPassword, setNewPassword] = useState(``);
  const [reConfirmNewPassword, setReconfirmPassword] = useState(``);

  const [secureCurrent, setSecureCurrent] = useState(true);
  const [secureNew, setSecureNew] = useState(true);
  const [secureConfirmNew, setSecureConfirmNew] = useState(true);

  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword || !reConfirmNewPassword) {
      toast.show(`Los 3 campos son obligatorios.`, {
        type: `danger`,
        placement: `top`,
        duration: 4000,
        animationType: `slide-in`
      });
      return;
    }
    if (newPassword !== reConfirmNewPassword) {
      toast.show(`Las contraseñas no coinciden.`, {
        type: `danger`,
        placement: `top`,
        duration: 4000,
        animationType: `slide-in`
      });
      return;
    }
    const token: string = tokenId!;
    const data: IPasswordChange = {
      currentPassword,
      newPassword,
      tokenId: token
    };
    const response = await changePassword(data, isFirstTime);
    if (response.changed) {
      toast.show(`Su contraseña ha sido cambiada con éxito`, {
        type: `success`,
        placement: `top`,
        duration: 4000,
        animationType: `slide-in`
      });
    } else {
      toast.show(response.message, {
        type: `danger`,
        placement: `top`,
        duration: 4000,
        animationType: `slide-in`
      });
    }
  };

  const newPasswordRef = useRef();
  const confirmNewPasswordRef = useRef();

  return (
    <View style={style.container}>
      <View style={style.changePassword}>
        <View style={style.prompts}>
          <Text style={style.titles}>Contraseña actual</Text>
        </View>
        <View style={style.input}>
          <TextInput
            style={{
              height: 50
            }}
            onSubmitEditing={() => {
              newPasswordRef.current.focus();
            }}
            secureTextEntry={secureCurrent}
            label={`Contraseña`}
            placeholder={`Contraseña`}
            value={currentPassword}
            onChangeText={(value) => setCurrentPassword(value)}
            underlineColor={`red`}
            activeUnderlineColor={`red`}
            right={
              <TextInput.Icon
                name="eye"
                onPress={() => {
                  setSecureCurrent(!secureCurrent);
                  return false;
                }}
              />
            }
          />
        </View>
        <View style={style.divider}></View>
        <View style={style.prompts}>
          <Text style={style.titles}>Nueva contraseña</Text>
        </View>
        <View style={style.input}>
          <TextInput
            style={{
              height: 50
            }}
            ref={newPasswordRef}
            onSubmitEditing={() => {
              confirmNewPasswordRef.current.focus();
            }}
            secureTextEntry={secureNew}
            label={`Nueva Contraseña`}
            placeholder={`Nueva Contraseña`}
            value={newPassword}
            onChangeText={(value) => setNewPassword(value)}
            underlineColor={`red`}
            activeUnderlineColor={`red`}
            right={
              <TextInput.Icon
                name="eye"
                onPress={() => {
                  setSecureNew(!secureNew);
                  return false;
                }}
              />
            }
          />
        </View>
        <View style={style.divider}></View>
        <View style={style.prompts}>
          <Text style={style.titles}>Confirmar contraseña actual</Text>
        </View>
        <View style={style.input}>
          <TextInput
            style={{
              height: 50
            }}
            ref={confirmNewPasswordRef}
            secureTextEntry={secureConfirmNew}
            label={`Confirmar Contraseña`}
            placeholder={`Confirmar Contraseña`}
            value={reConfirmNewPassword}
            onChangeText={(value) => setReconfirmPassword(value)}
            underlineColor={`red`}
            activeUnderlineColor={`red`}
            right={
              <TextInput.Icon
                name="eye"
                onPress={() => {
                  setSecureConfirmNew(!secureConfirmNew);
                  return false;
                }}
              />
            }
          />
        </View>
        <View style={style.divider}></View>
      </View>
      <View>
        <Button
          style={style.confirmButton}
          labelStyle={style.confirmButton.text}
          mode="contained"
          onPress={handleChangePassword}
        >
          CONFIRMAR
        </Button>
      </View>
    </View>
  );
}

const style = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: `center`,
    justifyContent: `flex-start`,
    backgroundColor: BACKGROUND_COLOUR
  },
  prompts: {
    marginLeft: 20,
    paddingBottom: 20
  },
  input: {
    marginHorizontal: 20
  },
  titles: {
    fontWeight: `300`,
    color: `black`,
    fontSize: 16 * fontScale,
    textAlign: `left`
  },
  divider: {
    alignSelf: `center`,
    width: `80%`,
    borderBottomColor: `white`,
    borderBottomWidth: 1,
    marginTop: 10,
    marginBottom: 10
  },
  changePassword: {
    marginTop: 130,
    width: 300,
    //flex: ,
    paddingTop: 10,
    backgroundColor: `#e0e0e0`,
    borderRadius: 15,
    shadowColor: `#bebebe`,
    shadowRadius: 20
  },
  confirmButton: {
    margin: `5%`,
    marginTop: `10%`,
    width: 220,
    backgroundColor: PRIMARY_COLOR,
    color: PRIMARY_TEXT_COLOR,
    borderRadius: 20,
    text: {
      fontSize: 24 * fontScale
    }
  }
});
