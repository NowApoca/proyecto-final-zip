import React, {useContext, useEffect, useState} from 'react';
import {View, Text, StyleSheet, Image, Linking, ScrollView} from 'react-native';
import HomeInfo from '../components/Home/HomeInfo';
import {PRIMARY_COLOR, SECONDARY_COLOR} from '../styles/common';
import {getNotifications, deleteAllNotifications, deleteNotificacion} from '../services/api';
import {useNavigation} from '@react-navigation/native';
import HomeCarousel from '../components/Home/HomeCarousel';
import {useToast} from 'react-native-toast-notifications';
import {getBoletinUrl} from '../services/api';
import {Dimensions} from 'react-native';
import {AuthContext} from '../navigation/AuthProvider';

export default function NotificationsScreen() {
  return <Notifications />;
}

function Notifications() {
  const {socioId} = useContext(AuthContext);
  const [notifications, setNotifications] = useState([]);
  const [refresh, setRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState();
  //setInterval(function () {
  //  setRefresh(!refresh);
  //}, 5000)

  useEffect(() => {
    getNotifications(socioId).then((response) => {
      if (response.status == 200) {
        setNotifications(response.data);
      }
    });
  }, [refresh]);

  const handleCleanNotifications = () => {
    deleteAllNotifications(socioId).then((response) => {
      if (response.status == 200) {
        getNotifications(socioId).then((response) => {
          if (response.status == 200) {
            setNotifications(response.data);
          }
        });
      }
    });
  };

  return (
    <View style={homeStyle.container}>
      <Text style={{fontSize: 25}}>Notificaciones</Text>
      <Text onPress={handleCleanNotifications} style={{fontSize: 15, color: `red`}}>
        Limpiar todo
      </Text>
      <ScrollView>
        {notifications.map((notification, index) => {
          return (
            <View style={homeStyle.notificationContainer}>
              <View style={homeStyle.xButton}>
                <Text
                  onPress={() => {
                    deleteNotificacion(notification.id).then((response) => {
                      if (response.status == 200) {
                        const copy = [].concat(notifications);
                        copy.splice(index, 1);
                        setNotifications(copy);
                      }
                    });
                  }}
                  style={{color: `red`}}
                >
                  X
                </Text>
              </View>
              <Text>{notification.message}</Text>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const homeStyle = StyleSheet.create({
  container: {
    padding: 40
  },
  notificationContainer: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: `gray`,
    padding: 20,
    marginTop: 15
  },
  xButton: {
    width: `100%`,
    display: `flex`,
    flexDirection: `column`,
    alignItems: `flex-end`
  }
});
