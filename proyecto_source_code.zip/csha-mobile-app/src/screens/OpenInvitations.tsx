import React from 'react';
import {Text, View} from 'react-native';

export default function OpenInvitations({}) {
  return (
    <View>
      <Text>TEXT IN OPEN INVITTATIONS</Text>
    </View>
  );
}
