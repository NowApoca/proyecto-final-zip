import React, {useContext, useEffect, useState} from 'react';
import {View, Text, StyleSheet, Image, Linking, ScrollView, Dimensions} from 'react-native';
import {PRIMARY_COLOR, PRIMARY_TEXT_COLOR, SECONDARY_COLOR} from '../styles/common';
import {useToast} from 'react-native-toast-notifications';
import {crearCancha, deleteCancha, editarCancha, getCanchas, getCanchaById, crearNotificacion} from '../services/api';
import {AuthContext} from '../navigation/AuthProvider';
import HourInput from '../components/Inputs/Hour';
import PermissionInput from '../components/Inputs/PermissionInput';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {PopUp} from './CreateInvitation';
import DateInput from '../components/Inputs/Date';

const windowHeight = Dimensions.get(`window`).height;
const horaMaxima = 20;
const horaMinima = 10;

const isSameDay = (date1, date2) => {
  return (
    date1.getDate() === date2.getDate() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getFullYear() === date2.getFullYear()
  );
};

export default function Canchas({}) {
  const [tab, setTab] = useState(`home`);
  const [canchaCurrentId, setCanchaCurrentId] = useState();

  return (
    <View style={homeStyle.container}>
      {tab == `home` && <MainCanchas setCanchaCurrentId={setCanchaCurrentId} setTab={setTab} />}
      {tab == `creational` && <CreateCancha setTab={setTab} />}
      {tab == `edit` && (
        <CreateCancha setCanchaCurrentId={setCanchaCurrentId} canchaCurrentId={canchaCurrentId} setTab={setTab} />
      )}
    </View>
  );
}

function CreateCancha({setTab, setCanchaCurrentId, canchaCurrentId}) {
  const {socioId} = useContext(AuthContext);
  const toast = useToast();
  const [llevaEquipo, setLlevarEquipo] = useState(true);
  const [canchaDeTenis, setCanchaDeTenis] = useState(false);
  const [canchaDeFutbol, setCanchaDeFutbol] = useState(false);
  const [canchaDePadel, setCanchaDePadel] = useState(false);
  const initialFromHour = new Date();
  initialFromHour.setHours(initialFromHour.getHours() + 1);
  initialFromHour.setMinutes(0, 0, 0);
  const initialToHour = new Date(initialFromHour);
  initialToHour.setHours(initialToHour.getHours() + 1);
  const [hour, setHour] = useState(initialFromHour);
  const [toHour, setToHour] = useState(initialToHour);
  const [date, setDate] = useState(new Date());

  useEffect(() => {
    if (canchaCurrentId != null && canchaCurrentId != undefined) {
      getCanchaById(canchaCurrentId).then((result) => {
        if (result.status == 200 && result.data) {
          setHour(new Date(result.data.entity.hour));
          setToHour(new Date(result.data.entity.toHour));
          setLlevarEquipo(result.data.entity.llevaEquipo);
          setCanchaDeTenis(result.data.entity.canchaDeTenis);
          setCanchaDeFutbol(result.data.entity.canchaDeFutbol);
          setCanchaDePadel(result.data.entity.canchaDePadel);
          setDate(new Date(result.data.entity.date));
        }
      });
    }
  }, []);

  return (
    <View>
      <View style={{minHeight: windowHeight - 300}}>
        <Text
          onPress={() => {
            setTab(`home`);
          }}
          style={{fontSize: 14, color: `red`}}
        >
          Volver
        </Text>
        <Text style={{fontSize: 25}}>Reservar cancha</Text>
        <PermissionInput
          text={`Cancha de tenis`}
          textLeft
          setter={() => {
            setCanchaDeTenis(!canchaDeTenis);
            setCanchaDeFutbol(false);
            setCanchaDePadel(false);
          }}
          value={canchaDeTenis}
        />
        <PermissionInput
          text={`Cancha de futbol`}
          textLeft
          setter={() => {
            setCanchaDeFutbol(!canchaDeFutbol);
            setCanchaDeTenis(false);
            setCanchaDePadel(false);
          }}
          value={canchaDeFutbol}
        />
        <PermissionInput
          text={`Cancha de padel`}
          textLeft
          setter={() => {
            setCanchaDePadel(!canchaDePadel);
            setCanchaDeFutbol(false);
            setCanchaDeTenis(false);
          }}
          value={canchaDePadel}
        />
        <View>
          <DateInput
            text={`Fecha`}
            value={date}
            setter={(newDate) => {
              const nowHours = new Date().getHours();
              if (isSameDay(newDate, hour) && hour.getHours() < nowHours) {
                const tempHour = new Date(hour);
                tempHour.setHours(nowHours);
                setHour(tempHour);
                const tempHour2 = new Date(tempHour);
                tempHour2.setHours(nowHours + 1);
                setToHour(tempHour2);
              }
              setDate(newDate);
            }}
          />
        </View>
        <View style={homeStyle.inputGroup}>
          <View style={{width: `30%`}}>
            <HourInput
              text={`Hora desde`}
              value={hour}
              minDate={(() => {
                const minFromHour = new Date();
                minFromHour.setMinutes(0, 0, 0);
                if (!isSameDay(minFromHour, date)) {
                  minFromHour.setHours(horaMinima);
                  return minFromHour;
                }
                return new Date();
              })()}
              setter={(fromHourTemp: Date) => {
                const toHourTemp = new Date(fromHourTemp);
                toHourTemp.setHours(fromHourTemp.getHours() + 1);
                setHour(fromHourTemp);
                setToHour(toHourTemp);
              }}
            />
          </View>
          <View style={{width: `30%`}}>
            <HourInput
              text={`Hora hasta`}
              minDate={(() => {
                const minToHour = new Date(hour);
                minToHour.setMinutes(hour.getMinutes() + 30);
                return minToHour;
              })()}
              maxDate={(() => {
                const maxToHour = new Date();
                maxToHour.setMinutes(0, 0, 0);
                maxToHour.setHours(horaMaxima);
                return maxToHour;
              })()}
              value={toHour}
              setter={setToHour}
            />
          </View>
          <View style={{width: `30%`}}>
            <PermissionInput text={`Lleva equipo?  `} textLeft setter={setLlevarEquipo} value={llevaEquipo} />
          </View>
        </View>
      </View>

      <View
        onTouchEnd={() => {
          if (hour > toHour) {
            toast.show(`La hora desde no puede ser mayor a la hora hasta.`, {
              type: `danger`,
              placement: `top`,
              duration: 4000,
              animationType: `slide-in`
            });
            return;
          }
          if (hour.getHours() < horaMinima - 1 || toHour.getHours() > horaMaxima - 1) {
            toast.show(`El periodo de reserva es de ${horaMinima} a ${horaMaxima}.`, {
              type: `danger`,
              placement: `top`,
              duration: 4000,
              animationType: `slide-in`
            });
            return;
          }
          if ((toHour.getTime() - hour.getTime()) / 1000 / 60 < 30) {
            toast.show(`La reserva minima es 30 mins.`, {
              type: `danger`,
              placement: `top`,
              duration: 4000,
              animationType: `slide-in`
            });
            return;
          }
          if (!canchaDeFutbol && !canchaDePadel && !canchaDeTenis) {
            toast.show(`Se debe elegir un tipo de cancha.`, {
              type: `danger`,
              placement: `top`,
              duration: 4000,
              animationType: `slide-in`
            });
            return;
          }
          if (canchaCurrentId) {
            editarCancha(canchaCurrentId, {
              hour,
              toHour,
              llevaEquipo,
              canchaDeTenis,
              canchaDeFutbol,
              canchaDePadel,
              idSocio: socioId,
              id: canchaCurrentId,
              date
            }).then((result) => {
              if (result.status == 200) {
                setTab(`home`);
                crearNotificacion({
                  message: `Reserva de cancha editada`,
                  idSocio: socioId
                });
              }
            });
          } else {
            crearCancha({
              hour,
              toHour,
              llevaEquipo,
              canchaDeTenis,
              canchaDeFutbol,
              canchaDePadel,
              idSocio: socioId,
              id: Math.round(Math.random() * 1000000000),
              date
            }).then((result) => {
              if (result.status == 200) {
                setTab(`home`);
                crearNotificacion({
                  message: `Reserva de cancha creada`,
                  idSocio: socioId
                });
              }
            });
          }
        }}
        style={homeStyle.button}
      >
        <Text style={homeStyle.textButton}>{canchaCurrentId ? `Guardar cambios` : `Reservar`}</Text>
      </View>
    </View>
  );
}

function MainCanchas({setTab, setCanchaCurrentId, canchaCurrentId}) {
  const {socioId} = useContext(AuthContext);
  const [canchas, setCanchas] = useState([]);
  const [popup, setPopup] = useState(false);
  const [currentId, setCurrentId] = useState(-1);

  useEffect(() => {
    getCanchas(socioId).then((response) => {
      if (response.status == 200) {
        setCanchas(
          response.data.map((cancha) => {
            let canchaType = ``;
            if (cancha.canchaDeTenis) {
              canchaType = `Tenis`;
            }
            if (cancha.canchaDeFutbol) {
              canchaType = `Futbol`;
            }
            if (cancha.canchaDePadel) {
              canchaType = `Padel`;
            }
            return {
              ...cancha,
              date: new Date(cancha.date),
              toHour: new Date(cancha.toHour),
              hour: new Date(cancha.hour),
              canchaType
            };
          })
        );
      }
    });
  }, [popup]);

  return (
    <ScrollView>
      <View style={{minHeight: 500}}>
        {canchas.map((cancha) => {
          return (
            <Cancha
              setCurrentId={setCurrentId}
              setPopup={setPopup}
              setTab={setTab}
              setCanchaCurrentId={setCanchaCurrentId}
              canchaData={cancha}
            />
          );
        })}
        {popup && (
          <PopUp
            Element={() => {
              return <DeleteCanchaPopup currentId={currentId} setCurrentId={setCurrentId} setPopup={setPopup} />;
            }}
          />
        )}
      </View>

      <View
        style={homeStyle.button}
        onTouchStart={() => {
          setTab(`creational`);
        }}
      >
        <Text onPress={() => {}} style={homeStyle.textButton}>
          {`Reservar cancha`}
        </Text>
      </View>
    </ScrollView>
  );
}

function DeleteCanchaPopup({setPopup, setCurrentId, currentId}) {
  const toast = useToast();
  const {tokenId} = useContext(AuthContext);

  return (
    <View>
      <Text style={{fontSize: 20, color: `red`, marginLeft: `5%`}}>Está seguro que desea cancelar la reserva?</Text>
      <View style={{display: `flex`, flexDirection: `row`, justifyContent: `space-around`}}>
        <View style={{...homeStyle.button, width: `40%`}}>
          <Text
            onPress={() => {
              setPopup(false);
            }}
            style={{
              fontWeight: `400`,
              color: `white`,
              fontSize: 22,
              textAlign: `center`
            }}
          >
            No
          </Text>
        </View>
        <View
          style={{...homeStyle.button, width: `40%`}}
          onTouchStart={() => {
            deleteCancha(currentId).then((result) => {
              if (result.status == 200) {
                setCurrentId(-1);
                setPopup(false);
              }
            });
          }}
        >
          <Text
            onPress={() => {}}
            style={{
              fontWeight: `400`,
              color: `white`,
              fontSize: 22,
              textAlign: `center`
            }}
          >
            Si
          </Text>
        </View>
      </View>
    </View>
  );
}

export function CanchasScreen() {
  return <Canchas></Canchas>;
}

function getHourFormatted(hour) {
  return `${hour.getHours()}:${hour.getMinutes() < 10 ? `0${hour.getMinutes()}` : hour.getMinutes()}`;
}

function getFormattedDate(date, hour, toHour) {
  return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()} ${getHourFormatted(hour)}/${getHourFormatted(
    toHour
  )}`;
}

function Cancha({canchaData, setCanchaCurrentId, setTab, setPopup, setCurrentId}) {
  return (
    <View style={homeStyle.canchaContainer}>
      <View style={homeStyle.canchaContainerTexts}>
        <Text>{canchaData.canchaType}</Text>
        <Text>{getFormattedDate(canchaData.date, canchaData.hour, canchaData.toHour)}</Text>
      </View>
      <View style={homeStyle.canchaContainerButtons}>
        <Text
          onPressIn={() => {
            setPopup(true);
            setCurrentId(canchaData.id);
          }}
          style={{marginRight: 15}}
          onPress={() => {}}
        >
          <FontAwesome name={`trash`} color={`red`} size={20} />
        </Text>
        <Text
          onPress={() => {
            setCanchaCurrentId(canchaData.id);
            setTab(`edit`);
          }}
          style={{marginRight: 15}}
        >
          <FontAwesome name={`edit`} color={`#444`} size={20} />
        </Text>
      </View>
    </View>
  );
}

const homeStyle = StyleSheet.create({
  container: {
    padding: 40
  },
  canchaContainer: {
    display: `flex`,
    flexDirection: `row`,
    justifyContent: `space-between`,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: `gray`,
    padding: 10,
    marginTop: 15
  },
  canchaContainerButtons: {
    display: `flex`,
    flexDirection: `row`,
    justifyContent: `space-between`,
    alignItems: `center`
  },
  canchaContainerTexts: {
    display: `flex`,
    flexDirection: `column`,
    justifyContent: `space-between`
  },
  inputGroup: {
    display: `flex`,
    flexDirection: `row`,
    justifyContent: `space-around`,
    width: `100%`,
    alignItems: `center`,
    marginTop: 10
  },
  textButton: {
    fontWeight: `400`,
    color: `white`,
    fontSize: 22,
    textAlign: `center`
  },
  button: {
    marginTop: 20,
    backgroundColor: PRIMARY_COLOR,
    color: PRIMARY_TEXT_COLOR,
    marginHorizontal: 80,
    borderRadius: 10,
    justifyContent: `center`,
    alignSelf: `center`,
    width: 300,
    height: 40
  }
});
