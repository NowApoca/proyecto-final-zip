import React, {useContext, useRef, useState} from 'react';
import {StyleSheet, View, ScrollView, Image, ActivityIndicator, Text} from 'react-native';
import {AuthContext} from '../navigation/AuthProvider';
import {IAuthtenticate} from '../services/types';
import {Button} from 'react-native-paper';
import EmailInput from '../components/Inputs/Email';
import IdentificationInput from '../components/Inputs/Identification';
import IdentificationTypeInput from '../components/Inputs/IdentificationType';
import PasswordInput from '../components/Inputs/Password';
import {BACKGROUND_COLOUR, PRIMARY_COLOR, PRIMARY_TEXT_COLOR} from '../styles/common';
import {useToast} from 'react-native-toast-notifications';
import {TextInput} from 'react-native-paper';
import {useNavigation} from '@react-navigation/native';

export default function LoginScreen({navigation}) {
  const toast = useToast();
  const {logIn} = useContext(AuthContext);
  const [email, setEmail] = useState(`demacomsistemas@gmail.com`);
  const [identification, setIdentification] = useState(`23123765`);
  const [identificationType, setIdentificationType] = useState(`DNI`);
  const [password, setPassword] = useState(`123456`);
  const [showLoading, setShowLoading] = useState(false);

  const handleLogIn = async () => {
    setShowLoading(true);
    const user: IAuthtenticate = {
      identificationType,
      identification,
      password,
      email
    };
    logIn(user).then((response) => {
      setShowLoading(false);
      if (!response.result && response.response.data && response.response.data.es_primer_ingreso == `NO`) {
        toast.show(`Error iniciando sesión. Contraseña y/o usuario incorrecto`, {
          type: `danger`,
          placement: `top`,
          duration: 4000,
          animationType: `slide-in`
        });
      }
      if (!response.data && !response.response?.data) {
        toast.show(`Error iniciando sesión.`, {
          type: `danger`,
          placement: `top`,
          duration: 4000,
          animationType: `slide-in`
        });
        return;
      }
      if (response.response.data.es_primer_ingreso == `SI` && response.response.data.resultado == `NO`) {
        toast.show(`Error iniciando sesión. Si es un usuario nuevo debe generar una contraseña.`, {
          type: `danger`,
          placement: `top`,
          duration: 4000,
          animationType: `slide-in`
        });
        navigation.navigate(`ForgotPassword`);
      }
    });
  };

  const emailRef = useRef();
  const passwordRef = useRef();

  return (
    <ScrollView>
      <View style={style.container}>
        <Image style={style.logo} source={require(`../assets/logo.png`)} />
        <IdentificationTypeInput setter={setIdentificationType} />

        <TextInput
          onSubmitEditing={() => {
            emailRef.current.focus();
          }}
          secureTextEntry={false}
          label={`Documento*`}
          placeholder={`Documento*`}
          value={identification}
          onChangeText={(value) => setIdentification(value)}
          underlineColor={`red`}
          activeUnderlineColor={`red`}
        />
        <TextInput
          onSubmitEditing={() => {
            passwordRef.current.focus();
          }}
          ref={emailRef}
          secureTextEntry={false}
          label={`Email*`}
          placeholder={`Email*`}
          value={email}
          onChangeText={(value) => setEmail(value)}
          underlineColor={`red`}
          activeUnderlineColor={`red`}
        />
        <TextInput
          ref={passwordRef}
          secureTextEntry={true}
          label={`Contraseña*`}
          placeholder={`Contraseña*`}
          value={password}
          onChangeText={(value) => setPassword(value)}
          underlineColor={`red`}
          activeUnderlineColor={`red`}
        />
      </View>
      <Button style={style.loginScreenButton} mode="contained" onPress={handleLogIn}>
        <Text style={{color: `white`}}>Ingresar</Text>
        {showLoading && <ActivityIndicator size="small" color="white" />}
      </Button>
      <Button style={style.forgotScreenButton} mode="contained" onPress={() => navigation.navigate(`ForgotPassword`)}>
        Recuperar contraseña
      </Button>
    </ScrollView>
  );
}

const style = StyleSheet.create({
  container: {
    display: `flex`,
    flex: 1,
    margin: `5%`,
    width: `90%`,
    backgroundColor: BACKGROUND_COLOUR
  },
  loginScreenButton: {
    margin: `5%`,
    width: `90%`,
    color: PRIMARY_TEXT_COLOR,
    backgroundColor: PRIMARY_COLOR
  },
  logo: {
    width: `50%`,
    height: 180,
    marginLeft: `25%`
  },
  forgotScreenButton: {
    margin: `5%`,
    width: `90%`,
    color: PRIMARY_COLOR,
    backgroundColor: PRIMARY_COLOR
  }
});
