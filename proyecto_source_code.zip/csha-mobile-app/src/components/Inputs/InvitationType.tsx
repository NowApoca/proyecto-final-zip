import React, {useContext, useState} from 'react';
import SelectDropdown from 'react-native-select-dropdown';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Text, View} from 'react-native';
import {useEffect} from 'react';
import {getInvitationTypes} from '../../services/api';
import {fontScale} from '../../styles/common';
import {AuthContext} from '../../navigation/AuthProvider';

export default function InvitationType({setter, value}) {
  const [invitationTypes, setInvitationTypes] = useState([]);
  const {permisos} = useContext(AuthContext);

  const invitationsById = {};

  invitationTypes.map((entity) => {
    invitationsById.id = entity.valor_codigo;
    invitationsById.label = entity.valor_desc;
  });

  useEffect(() => {
    getInvitationTypes().then((result) => {
      const invitationTypes = [];
      result.forEach((invitationType) => {
        if (
          invitationType.valor_codigo == `INSTITUCIONAL` &&
          permisos[`INVITADOS`] &&
          permisos[`INVITADOS`][`INSTITUCIONALES`]
        ) {
          invitationTypes.push({
            label: invitationType.valor_desc,
            id: invitationType.valor_codigo
          });
        }
        if (invitationType.valor_codigo != `INSTITUCIONAL`) {
          invitationTypes.push({
            label: invitationType.valor_desc,
            id: invitationType.valor_codigo
          });
        }
      });
      setInvitationTypes(invitationTypes);
    });
  }, []);

  return (
    <SelectDropdown
      data={invitationTypes}
      onSelect={(selectedItem) => {
        setter(selectedItem);
      }}
      renderDropdownIcon={(isOpened) => {
        return <FontAwesome name={isOpened ? `chevron-up` : `chevron-down`} color={`#444`} size={18 * fontScale} />;
      }}
      renderCustomizedButtonChild={(selectedItem, index) => {
        return (
          <View>
            <Text>{selectedItem?.label || value?.label || value || `SELECCIONAR TIPO DE INVITADO...`}</Text>
          </View>
        );
      }}
      buttonTextAfterSelection={(selectedItem, index) => {
        return selectedItem.label;
      }}
      buttonStyle={{
        borderWidth: 1,
        width: `100%`
      }}
      rowTextForSelection={(item, index) => {
        return item.label;
      }}
    />
  );
}
