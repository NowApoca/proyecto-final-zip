import React from 'react';
import Input from './Input';

export default function IdentificationInput({value, setter, mandatory}) {
  return (
    <Input
      label={`Documento${mandatory ? `*` : ``}`}
      placeholder={`Documento${mandatory ? `*` : ``}`}
      setter={setter}
      value={value}
    />
  );
}
