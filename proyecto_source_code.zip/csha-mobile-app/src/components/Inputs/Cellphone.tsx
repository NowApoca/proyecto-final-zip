import React from 'react';
import Input from './Input';

export default function CellphoneInput({value, setter, mandatory, onSubmitEditing}) {
  return (
    <Input
      onSubmitEditing={onSubmitEditing}
      label={`Celular${mandatory ? `*` : ``}`}
      placeholder={`Celular`}
      setter={setter}
      value={value}
    />
  );
}
