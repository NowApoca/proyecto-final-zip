import React from 'react';
import Input from './Input';

export default function EmailInput({value, ref, setter, mandatory, onSubmitEditing}) {
  const RefInput = React.forwardRef((props, ref) => (
    <Input
      ref={ref}
      onSubmitEditing={onSubmitEditing}
      label={`Email${mandatory ? `*` : ``}`}
      placeholder={`Email`}
      setter={setter}
      value={value}
    />
  ));

  return <RefInput ref={ref} />;
}
