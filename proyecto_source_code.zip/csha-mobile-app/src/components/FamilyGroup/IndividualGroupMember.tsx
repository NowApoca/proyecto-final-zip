import React, {useContext, useEffect, useState} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import {AuthContext} from '../../navigation/AuthProvider';
import {apiGetSocioById} from '../../services/api';
import {BACKGROUND_COLOUR, fontScale, GREY_CONTAINER_BACKGROUND} from '../../styles/common';
import ProfileBanner from '../MyProfile/ProfileBanner';
import ProfileFooter from '../MyProfile/ProfileFooter';
import IndividualGroupData from './IndividualGroupData';
import IndividualGroupPermissions from './IndividualGroupPermissions';

const IndividualGroupMember = ({route, navigation}) => {
  const {tokenId} = useContext(AuthContext);
  const {currentData} = route.params;
  const profile = {name: currentData.name, email: currentData.email};
  const [data, setData] = useState();

  useEffect(() => {
    apiGetSocioById(tokenId, currentData.socio_id).then((response) => {
      setData({
        name: `${response.data.socio_nombre[0].toUpperCase()}${response.data.socio_nombre
          .substring(1)
          .toLowerCase()} ${response.data.socio_apellido[0].toUpperCase()}${response.data.socio_apellido
          .substring(1)
          .toLowerCase()}`,
        email: response.data.email,
        link_imagen: response.data.link_imagen,
        parentesco: response.data.parentesco_nombre,
        birthdate: response.data.fecha_nacimiento,
        puede_invitar_con_aut: response.data.puede_invitar_con_aut == `Si` ? true : false,
        puede_invitar_sin_aut: response.data.puede_invitar_sin_aut == `Si` ? true : false,
        flag_inv_puede_aut: response.data.flag_inv_puede_aut == `Si` ? true : false,
        phone: response.data.tel_celular,
        id: response.data.documento_nro,
        socio_id: response.data.socio_id
      });
    });
    setData(``);
  }, [currentData.socio_id]);

  console.log(data, `DATAAAAA`);

  return (
    <ScrollView>
      <View style={style.container}>
        {data && (
          <>
            <ProfileBanner data={data} />
            <IndividualGroupData data={data} />
            <IndividualGroupPermissions data={data} />
          </>
        )}
      </View>
    </ScrollView>
  );
};

const style = StyleSheet.create({
  container: {
    backgroundColor: BACKGROUND_COLOUR,
    alignItems: `center`,
    margin: 10
  },
  mainTitleContainer: {
    marginBottom: 5,
    padding: 5
  },
  mainTitle: {
    fontWeight: `300`,
    color: `black`,
    fontSize: 18 * fontScale,
    textAlign: `left`
  },
  infoContainer: {
    width: 300,
    padding: 15,
    backgroundColor: GREY_CONTAINER_BACKGROUND,
    borderRadius: 15,
    shadowColor: `#bebebe`,
    shadowRadius: 20
  },
  titles: {
    fontWeight: `400`,
    color: `black`,
    fontSize: 19 * fontScale,
    textAlign: `left`
  },
  dataContainer: {
    width: 300,
    backgroundColor: GREY_CONTAINER_BACKGROUND,
    padding: 10,
    paddingBottom: 0,
    borderRadius: 15,
    shadowColor: `#bebebe`,
    shadowRadius: 20,
    marginBottom: 0
  },
  prompts: {
    marginLeft: 20,
    paddingBottom: 20
  },
  divider: {
    alignSelf: `center`,
    width: `80%`,
    borderBottomColor: `white`,
    borderBottomWidth: 1,
    marginTop: 10,
    marginBottom: 10
  }
});

export default IndividualGroupMember;
